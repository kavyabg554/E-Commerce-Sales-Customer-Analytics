import os

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'ecom_bi_corporate_secret_key_2026_mca'
    BASE_DIR = os.path.abspath(os.path.dirname(__file__))
    DATA_DIR = os.path.join(BASE_DIR, 'data')
    UPLOAD_FOLDER = os.path.join(DATA_DIR, 'uploads')
    DATASET_PATH = os.path.join(DATA_DIR, 'ecommerce_data.csv')
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16MB max upload

# E-Commerce Sales & Customer Analytics Dashboard 📊

A complete, enterprise-grade **Corporate Business Intelligence (BI) & Customer Analytics Portal** built for MCA Data Analytics portfolios.

Designed with a modern **Power BI / Tableau / SaaS-inspired interface**, this web application processes raw e-commerce transaction data, executes automated data cleaning pipelines via Pandas, loads standardized datasets into a SQLite database engine, computes RFM customer segmentation, and serves interactive Plotly.js dashboards.

---

## 🌟 Tech Stack & Architecture

- **Backend**: Python 3, Flask, Werkzeug
- **Data Engineering & Analytics**: Pandas, NumPy, SQLite3, OpenPyXL
- **Frontend**: HTML5, Vanilla CSS3 (Custom Corporate Navy SaaS Design System), Modern JavaScript (ES6+)
- **Visualizations**: Plotly.js (Interactive line, bar, donut, and pie charts), FontAwesome 6
- **Architecture**: `CSV/Excel Upload → Pandas Data Cleaning Engine → SQLite Storage → Flask REST Endpoints → Interactive Web UI`

---

## 🚀 Key Features

### 1. Executive BI Overview Dashboard
- **6 Key Metrics Cards**: Gross Revenue, Net Profit, Total Orders, Total Unique Customers, Average Order Value (AOV), and Profit Margin %.
- **Interactive Multi-Filter Bar**: Filter analytics dynamically by Date Range, Product Category, Region, Customer Type, and Specific Product.
- **Monthly Sales & Profit Trend**: Dual-axis bar and line chart showing revenue, profit, and margin % over time.
- **Category Share Donut Chart**: Visual distribution of revenue across product verticals.

### 2. Products & Category Performance
- Category & Subcategory financial metrics (Revenue, Net Profit, Units Sold, Margin %).
- High Revenue vs Low Margin product optimization indicators.
- Interactive Searchable Product Performance Catalog.

### 3. RFM Customer Segmentation & Loyalty Analytics
- **RFM Engine (Recency, Frequency, Monetary)**: Categorizes customer behavior into 5 actionable segments:
  - 🌟 **Champions**
  - 💎 **Loyal Customers**
  - 📈 **Potential Loyalists**
  - ⚠️ **At Risk**
  - 💤 **Hibernating**
- **Customer Repeat Purchase Rate**: Tracks retention % and repeat buyer count.
- **High-Value Customer Leaderboard**: Ranks top spending customers with lifetime values.

### 4. Regional & State Performance
- Geographic comparison across North, South, East, West, and Central zones.
- State-level revenue breakdown chart.
- Payment method breakdown (UPI, Credit Card, Net Banking, PayPal, Debit Card).
- Order status fulfillment metrics (Delivered, Shipped, Processing, Returned, Cancelled).

### 5. Data Quality Audit & Interactive SQL Console
- **Automated Pandas Data Cleaner**:
  - Trims leading/trailing whitespace.
  - Imputes missing numerical/categorical values.
  - Converts and standardizes date formats (`YYYY-MM-DD`).
  - Strips duplicate records.
  - Generates a **Data Health Score (0-100%)**.
- **Interactive SQL Query Console**: Run custom read-only `SELECT` queries directly against the SQLite `sales_data` table. Includes pre-loaded one-click SQL query templates.
- **Dataset File Upload**: Upload custom CSV or Excel files (`.xlsx`).

### 6. Automated Business Insights & PDF Export
- Rule-based AI narrative insight generator highlighting revenue drivers, customer risk warnings, and margin improvement strategies.
- One-click **Export Cleaned CSV Data** and **Printable Executive PDF Report**.
- Responsive **Dark/Light Mode Theme Toggle**.

---

## 📁 Directory Structure

```
E-Commerce Sales & Customer Analytics/
├── app.py                      # Flask server, routes, REST API endpoints
├── config.py                   # App configuration & upload limits
├── generate_data.py            # Synthetic 1200+ record dataset generator
├── requirements.txt            # Python dependencies
├── README.md                   # Project documentation
├── modules/
│   ├── __init__.py
│   ├── data_cleaner.py         # Pandas automated data cleaning & health report
│   ├── db_engine.py            # SQLite engine, indexer, safe SQL console
│   ├── analytics_engine.py     # KPIs, RFM segmentation, aggregations
│   └── insight_generator.py    # Rule-based business recommendations engine
├── data/
│   ├── ecommerce_data.csv      # Cleaned transaction dataset
│   └── ecommerce.db            # SQLite database
├── static/
│   ├── css/
│   │   └── styles.css          # Deep navy SaaS CSS design system
│   └── js/
│       ├── main.js             # Theme, modal, filter controller
│       ├── charts.js           # Plotly.js chart initializers
│       └── sql_console.js      # Interactive SQL console controller
└── templates/
    ├── base.html               # Master layout with sidebar & header
    ├── login.html              # Corporate login page
    ├── dashboard.html          # Executive Summary tab
    ├── products.html           # Products & Categories tab
    ├── customers.html          # RFM Customer Analytics tab
    ├── regional.html           # Regional Performance tab
    ├── data_management.html    # Data Upload & SQL Console tab
    └── insights.html           # Automated Business Insights tab
```

---

## ⚙️ Installation & Running Locally

### 1. Prerequisites
Ensure Python 3.9+ is installed on your system.

### 2. Install Dependencies
Open terminal in project directory:
```bash
pip install -r requirements.txt
```

### 3. Generate Benchmark Dataset (Optional, auto-runs on launch)
```bash
python generate_data.py
```

### 4. Run the Flask Server
```bash
python app.py
```

### 5. Access the Web Application
Open your browser and navigate to:
`http://127.0.0.1:5000`

**Login Credentials**:
- Username: `admin`
- Password: `admin123`
- Or click **"Quick Demo Access"** button.

---

## 📊 Sample SQL Queries (For MCA viva / evaluation)

### 1. Monthly Revenue & Profit
```sql
SELECT 
  strftime('%Y-%m', order_date) AS month,
  COUNT(DISTINCT order_id) AS total_orders,
  ROUND(SUM(sales_amount), 2) AS revenue,
  ROUND(SUM(profit), 2) AS net_profit,
  ROUND(AVG(profit_margin), 2) AS avg_margin_pct
FROM sales_data
GROUP BY month
ORDER BY month ASC;
```

### 2. High-Revenue Categories
```sql
SELECT 
  category,
  COUNT(DISTINCT order_id) AS total_orders,
  SUM(quantity) AS units_sold,
  ROUND(SUM(sales_amount), 2) AS total_revenue,
  ROUND(SUM(profit), 2) AS total_profit
FROM sales_data
GROUP BY category
ORDER BY total_revenue DESC;
```

---

## 📜 License & MCA Portfolio Attribution
Developed as an MCA Data Analytics Capstone Portfolio Project. Free for educational and commercial demonstration.

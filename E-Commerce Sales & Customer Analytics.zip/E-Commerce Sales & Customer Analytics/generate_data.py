import os
import random
import pandas as pd
from datetime import datetime, timedelta

def generate_ecommerce_dataset(output_path="data/ecommerce_data.csv", num_records=1250):
    """
    Generates a realistic synthetic e-commerce sales & customer dataset (1200+ records)
    spanning 2024 to early 2026 for Data Analytics & BI applications.
    """
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    
    random.seed(42)  # For reproducible dataset generation
    
    # 1. Base Product Catalog
    products_catalog = [
        {"id": "PRD-101", "name": "ProBook Ultrabook 15", "category": "Electronics", "subcategory": "Laptops", "cost": 650.0, "price": 999.0},
        {"id": "PRD-102", "name": "Gaming Laptop Xtreme", "category": "Electronics", "subcategory": "Laptops", "cost": 950.0, "price": 1499.0},
        {"id": "PRD-103", "name": "Flagship Smartphone Z", "category": "Electronics", "subcategory": "Mobiles", "cost": 450.0, "price": 799.0},
        {"id": "PRD-104", "name": "Wireless Noise-Canceling Headphones", "category": "Electronics", "subcategory": "Audio", "cost": 80.0, "price": 199.0},
        {"id": "PRD-105", "name": "True Wireless Earbuds", "category": "Electronics", "subcategory": "Audio", "cost": 30.0, "price": 89.0},
        {"id": "PRD-106", "name": "Smart Fitness Watch Ultra", "category": "Electronics", "subcategory": "Wearables", "cost": 110.0, "price": 249.0},
        {"id": "PRD-107", "name": "4K Smart OLED TV 55\"", "category": "Electronics", "subcategory": "Television", "cost": 600.0, "price": 1099.0},
        {"id": "PRD-108", "name": "Mechanical RGB Keyboard", "category": "Electronics", "subcategory": "Accessories", "cost": 45.0, "price": 119.0},
        
        {"id": "PRD-201", "name": "Ergonomic Mesh Office Chair", "category": "Home & Kitchen", "subcategory": "Furniture", "cost": 120.0, "price": 279.0},
        {"id": "PRD-202", "name": "Standing Electric Desk", "category": "Home & Kitchen", "subcategory": "Furniture", "cost": 220.0, "price": 499.0},
        {"id": "PRD-203", "name": "Automatic Espresso Machine", "category": "Home & Kitchen", "subcategory": "Appliances", "cost": 180.0, "price": 389.0},
        {"id": "PRD-204", "name": "Air Fryer XL 5.5L", "category": "Home & Kitchen", "subcategory": "Appliances", "cost": 50.0, "price": 129.0},
        {"id": "PRD-205", "name": "Robot Vacuum Cleaner", "category": "Home & Kitchen", "subcategory": "Appliances", "cost": 160.0, "price": 349.0},
        
        {"id": "PRD-301", "name": "Men's Waterproof Trail Jacket", "category": "Fashion & Apparel", "subcategory": "Outerwear", "cost": 35.0, "price": 95.0},
        {"id": "PRD-302", "name": "Women's Designer Handbag", "category": "Fashion & Apparel", "subcategory": "Bags", "cost": 75.0, "price": 220.0},
        {"id": "PRD-303", "name": "Pro Running Sneakers", "category": "Fashion & Apparel", "subcategory": "Footwear", "cost": 45.0, "price": 135.0},
        {"id": "PRD-304", "name": "100% Organic Cotton Hoodie", "category": "Fashion & Apparel", "subcategory": "Apparel", "cost": 18.0, "price": 55.0},
        {"id": "PRD-305", "name": "Polarized Sunglasses Sport", "category": "Fashion & Apparel", "subcategory": "Accessories", "cost": 15.0, "price": 65.0},
        
        {"id": "PRD-401", "name": "Hydrating Facial Serum Set", "category": "Beauty & Personal Care", "subcategory": "Skincare", "cost": 12.0, "price": 48.0},
        {"id": "PRD-402", "name": "Sonic Electric Toothbrush", "category": "Beauty & Personal Care", "subcategory": "Personal Care", "cost": 25.0, "price": 79.0},
        {"id": "PRD-403", "name": "Luxury Eau De Parfum 100ml", "category": "Beauty & Personal Care", "subcategory": "Fragrance", "cost": 30.0, "price": 115.0},
        
        {"id": "PRD-501", "name": "Adjustable Dumbbell Set 24kg", "category": "Sports & Fitness", "subcategory": "Gym Equipment", "cost": 110.0, "price": 259.0},
        {"id": "PRD-502", "name": "Non-Slip Yoga Mat Pro", "category": "Sports & Fitness", "subcategory": "Fitness", "cost": 10.0, "price": 38.0},
        {"id": "PRD-503", "name": "Insulated Stainless Water Bottle", "category": "Sports & Fitness", "subcategory": "Fitness", "cost": 6.0, "price": 25.0}
    ]

    # 2. Customers Pool (350 distinct customers to form repeat buyers for RFM)
    first_names = ["Rahul", "Priya", "Amit", "Sneha", "Vikram", "Ananya", "Rohan", "Kavya", "Siddharth", "Neha", 
                   "David", "Emma", "Alex", "Sophia", "Michael", "Olivia", "James", "Isabella", "Daniel", "Mia",
                   "Arjun", "Deepika", "Karan", "Pooja", "Rajesh", "Meera", "Aarav", "Tanya", "Sanjay", "Ritu"]
    last_names = ["Sharma", "Patel", "Verma", "Roy", "Singh", "Nair", "Gupta", "Deshmukh", "Iyer", "Chopra", 
                  "Smith", "Johnson", "Brown", "Taylor", "Miller", "Wilson", "Anderson", "Thomas", "White", "Harris"]

    customer_pool = []
    customer_types = ["Retail", "Retail", "Retail", "Corporate", "VIP", "Wholesale"]
    for i in range(1, 351):
        fn = random.choice(first_names)
        ln = random.choice(last_names)
        c_type = random.choice(customer_types)
        c_gender = "Female" if fn in ["Priya", "Sneha", "Ananya", "Kavya", "Neha", "Sophia", "Emma", "Olivia", "Isabella", "Mia", "Deepika", "Pooja", "Meera", "Tanya", "Ritu"] else "Male"
        customer_pool.append({
            "customer_id": f"CUST-{1000 + i}",
            "customer_name": f"{fn} {ln}",
            "gender": c_gender,
            "customer_type": c_type
        })

    # 3. Regional mapping (Region -> States & Cities)
    regions_map = {
        "North": [
            {"state": "Delhi", "city": "New Delhi"},
            {"state": "Punjab", "city": "Chandigarh"},
            {"state": "Uttar Pradesh", "city": "Noida"},
            {"state": "Haryana", "city": "Gurugram"}
        ],
        "South": [
            {"state": "Karnataka", "city": "Bengaluru"},
            {"state": "Tamil Nadu", "city": "Chennai"},
            {"state": "Telangana", "city": "Hyderabad"},
            {"state": "Kerala", "city": "Kochi"}
        ],
        "West": [
            {"state": "Maharashtra", "city": "Mumbai"},
            {"state": "Maharashtra", "city": "Pune"},
            {"state": "Gujarat", "city": "Ahmedabad"},
            {"state": "Goa", "city": "Panaji"}
        ],
        "East": [
            {"state": "West Bengal", "city": "Kolkata"},
            {"state": "Odisha", "city": "Bhubaneswar"},
            {"state": "Assam", "city": "Guwahati"}
        ],
        "Central": [
            {"state": "Madhya Pradesh", "city": "Indore"},
            {"state": "Rajasthan", "city": "Jaipur"},
            {"state": "Chhattisgarh", "city": "Raipur"}
        ]
    }

    payment_methods = ["UPI", "Credit Card", "Credit Card", "Net Banking", "PayPal", "Debit Card"]
    statuses = ["Delivered", "Delivered", "Delivered", "Delivered", "Shipped", "Processing", "Returned", "Cancelled"]

    start_date = datetime(2024, 1, 1)
    end_date = datetime(2026, 3, 15)
    total_days = (end_date - start_date).days

    rows = []
    
    for order_idx in range(1, num_records + 1):
        order_id = f"ORD-{202400 + order_idx}"
        
        # Pick customer (weighted towards repeat customers to create realistic RFM dynamics)
        cust = random.choice(customer_pool)
        
        # Pick Product
        prod = random.choice(products_catalog)
        
        # Quantity
        if cust["customer_type"] == "Wholesale":
            qty = random.randint(5, 15)
        elif cust["customer_type"] == "Corporate":
            qty = random.randint(3, 8)
        else:
            qty = random.randint(1, 4)
            
        # Discount (0% to 25%)
        discount_pct = random.choice([0.0, 0.0, 0.0, 5.0, 10.0, 15.0, 20.0, 25.0])
        
        # Calculate pricing
        unit_price = prod["price"]
        unit_cost = prod["cost"]
        gross_amount = unit_price * qty
        discount_amount = round(gross_amount * (discount_pct / 100.0), 2)
        sales_amount = round(gross_amount - discount_amount, 2)
        total_cost = round(unit_cost * qty, 2)
        profit = round(sales_amount - total_cost, 2)
        profit_margin = round((profit / sales_amount * 100.0), 2) if sales_amount > 0 else 0.0
        
        # Order Date (weighted towards recent months to show realistic trends)
        day_offset = int(random.triangular(0, total_days, total_days * 0.75))
        order_date = start_date + timedelta(days=day_offset)
        order_date_str = order_date.strftime("%Y-%m-%d")
        
        # Location
        region_name = random.choice(list(regions_map.keys()))
        loc_info = random.choice(regions_map[region_name])
        
        # Payment & Status
        payment = random.choice(payment_methods)
        status = random.choice(statuses)
        
        # Add slight intentional whitespace noise on 3% of text fields for data cleaner demonstration
        cust_name_val = cust["customer_name"]
        if random.random() < 0.03:
            cust_name_val = f"  {cust_name_val}  "
            
        category_val = prod["category"]
        if random.random() < 0.02:
            category_val = f"{category_val} "

        rows.append({
            "order_id": order_id,
            "order_date": order_date_str,
            "customer_id": cust["customer_id"],
            "customer_name": cust_name_val,
            "gender": cust["gender"],
            "customer_type": cust["customer_type"],
            "product_id": prod["id"],
            "product_name": prod["name"],
            "category": category_val,
            "subcategory": prod["subcategory"],
            "unit_price": unit_price,
            "quantity": qty,
            "discount_percent": discount_pct,
            "discount_amount": discount_amount,
            "sales_amount": sales_amount,
            "unit_cost": unit_cost,
            "profit": profit,
            "profit_margin": profit_margin,
            "region": region_name,
            "state": loc_info["state"],
            "city": loc_info["city"],
            "payment_method": payment,
            "order_status": status
        })

    # Convert to DataFrame
    df = pd.DataFrame(rows)
    df.to_csv(output_path, index=False)
    print(f"✅ Generated dataset with {len(df)} records saved to {output_path}")

if __name__ == "__main__":
    generate_ecommerce_dataset()

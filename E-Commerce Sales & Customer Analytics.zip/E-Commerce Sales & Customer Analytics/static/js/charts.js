/**
 * Charting & Visualization Library for E-Commerce BI Dashboard
 * Powered by Plotly.js for interactive corporate visualizations.
 */

function getChartThemeColors() {
    const isLight = document.body.classList.contains('light-mode');
    return {
        paper_bg: isLight ? '#ffffff' : '#1e293b',
        plot_bg: isLight ? '#ffffff' : '#1e293b',
        text_color: isLight ? '#0f172a' : '#f8fafc',
        grid_color: isLight ? '#e2e8f0' : '#334155',
        primary: '#6366f1',
        secondary: '#10b981',
        warning: '#f59e0b',
        danger: '#f43f5e',
        purple: '#a855f7',
        cyan: '#06b6d4'
    };
}

/* --- 1. Monthly Revenue & Profit Trend Chart --- */
function renderMonthlyTrendChart(containerId, trends) {
    const colors = getChartThemeColors();
    if (!trends || !trends.length) return;

    const months = trends.map(t => t.month);
    const revenues = trends.map(t => t.revenue);
    const profits = trends.map(t => t.profit);
    const margins = trends.map(t => t.margin);

    const traceRevenue = {
        x: months,
        y: revenues,
        name: 'Gross Revenue ($)',
        type: 'bar',
        marker: { color: colors.primary, opacity: 0.85 }
    };

    const traceProfit = {
        x: months,
        y: profits,
        name: 'Net Profit ($)',
        type: 'bar',
        marker: { color: colors.secondary, opacity: 0.85 }
    };

    const traceMargin = {
        x: months,
        y: margins,
        name: 'Profit Margin %',
        type: 'scatter',
        mode: 'lines+markers',
        yaxis: 'y2',
        line: { color: colors.warning, width: 3 },
        marker: { size: 6 }
    };

    const layout = {
        autosize: true,
        margin: { l: 50, r: 50, t: 30, b: 50 },
        paper_bgcolor: colors.paper_bg,
        plot_bgcolor: colors.plot_bg,
        font: { color: colors.text_color, family: 'Inter, sans-serif' },
        barmode: 'group',
        legend: { orientation: 'h', y: 1.15, x: 0 },
        xaxis: { gridcolor: colors.grid_color },
        yaxis: { title: 'Amount ($)', gridcolor: colors.grid_color },
        yaxis2: {
            title: 'Margin %',
            overlaying: 'y',
            side: 'right',
            showgrid: false,
            ticksuffix: '%'
        }
    };

    Plotly.newPlot(containerId, [traceRevenue, traceProfit, traceMargin], layout, { responsive: true, displayModeBar: false });
}

/* --- 2. Category Performance Donut / Bar Chart --- */
function renderCategoryChart(containerId, categories) {
    const colors = getChartThemeColors();
    if (!categories || !categories.length) return;

    const labels = categories.map(c => c.category);
    const values = categories.map(c => c.revenue);
    const colorPalette = [colors.primary, colors.secondary, colors.cyan, colors.purple, colors.warning];

    const data = [{
        values: values,
        labels: labels,
        type: 'pie',
        hole: 0.55,
        marker: { colors: colorPalette },
        textinfo: 'label+percent',
        hoverinfo: 'label+value+percent'
    }];

    const layout = {
        autosize: true,
        margin: { l: 20, r: 20, t: 20, b: 20 },
        paper_bgcolor: colors.paper_bg,
        font: { color: colors.text_color, family: 'Inter, sans-serif' },
        legend: { orientation: 'h', y: -0.1 }
    };

    Plotly.newPlot(containerId, data, layout, { responsive: true, displayModeBar: false });
}

/* --- 3. Top Products Horizontal Bar Chart --- */
function renderTopProductsChart(containerId, products) {
    const colors = getChartThemeColors();
    if (!products || !products.length) return;

    const sorted = [...products].reverse();
    const names = sorted.map(p => p.product_name);
    const revenues = sorted.map(p => p.revenue);

    const data = [{
        x: revenues,
        y: names,
        type: 'bar',
        orientation: 'h',
        marker: {
            color: colors.primary,
            opacity: 0.9
        }
    }];

    const layout = {
        autosize: true,
        margin: { l: 150, r: 30, t: 20, b: 40 },
        paper_bgcolor: colors.paper_bg,
        plot_bgcolor: colors.plot_bg,
        font: { color: colors.text_color, family: 'Inter, sans-serif' },
        xaxis: { title: 'Revenue ($)', gridcolor: colors.grid_color },
        yaxis: { gridcolor: colors.grid_color }
    };

    Plotly.newPlot(containerId, data, layout, { responsive: true, displayModeBar: false });
}

/* --- 4. RFM Customer Segmentation Chart --- */
function renderRFMSegmentsChart(containerId, segments) {
    const colors = getChartThemeColors();
    if (!segments || !segments.length) return;

    const labels = segments.map(s => s.segment);
    const values = segments.map(s => s.customer_count);
    const segColors = [colors.secondary, colors.primary, colors.cyan, colors.warning, colors.danger];

    const data = [{
        values: values,
        labels: labels,
        type: 'pie',
        hole: 0.45,
        marker: { colors: segColors },
        textinfo: 'label+value'
    }];

    const layout = {
        autosize: true,
        margin: { l: 20, r: 20, t: 20, b: 20 },
        paper_bgcolor: colors.paper_bg,
        font: { color: colors.text_color, family: 'Inter, sans-serif' },
        legend: { orientation: 'h', y: -0.15 }
    };

    Plotly.newPlot(containerId, data, layout, { responsive: true, displayModeBar: false });
}

/* --- 5. Regional Sales & Profit Grouped Bar Chart --- */
function renderRegionalChart(containerId, regionalData) {
    const colors = getChartThemeColors();
    if (!regionalData || !regionalData.length) return;

    const regions = regionalData.map(r => r.region);
    const revenues = regionalData.map(r => r.revenue);
    const profits = regionalData.map(r => r.profit);

    const trace1 = {
        x: regions,
        y: revenues,
        name: 'Revenue ($)',
        type: 'bar',
        marker: { color: colors.primary }
    };

    const trace2 = {
        x: regions,
        y: profits,
        name: 'Profit ($)',
        type: 'bar',
        marker: { color: colors.secondary }
    };

    const layout = {
        autosize: true,
        margin: { l: 40, r: 40, t: 30, b: 40 },
        paper_bgcolor: colors.paper_bg,
        plot_bgcolor: colors.plot_bg,
        font: { color: colors.text_color, family: 'Inter, sans-serif' },
        barmode: 'group',
        legend: { orientation: 'h', y: 1.15 },
        xaxis: { gridcolor: colors.grid_color },
        yaxis: { title: 'Amount ($)', gridcolor: colors.grid_color }
    };

    Plotly.newPlot(containerId, [trace1, trace2], layout, { responsive: true, displayModeBar: false });
}

/* --- 6. Top States Performance Chart --- */
function renderStatesChart(containerId, stateData) {
    const colors = getChartThemeColors();
    if (!stateData || !stateData.length) return;

    const states = stateData.map(s => s.state);
    const revenues = stateData.map(s => s.revenue);

    const data = [{
        x: states,
        y: revenues,
        type: 'bar',
        marker: { color: colors.cyan }
    }];

    const layout = {
        autosize: true,
        margin: { l: 50, r: 30, t: 20, b: 70 },
        paper_bgcolor: colors.paper_bg,
        plot_bgcolor: colors.plot_bg,
        font: { color: colors.text_color, family: 'Inter, sans-serif' },
        xaxis: { tickangle: -35, gridcolor: colors.grid_color },
        yaxis: { title: 'Revenue ($)', gridcolor: colors.grid_color }
    };

    Plotly.newPlot(containerId, data, layout, { responsive: true, displayModeBar: false });
}

/**
 * Interactive SQL Query Console Controller
 */

document.addEventListener('DOMContentLoaded', () => {
    initSqlConsole();
});

function initSqlConsole() {
    const runBtn = document.getElementById('run-sql-btn');
    const sqlTextarea = document.getElementById('sql-query-input');
    const templatePills = document.querySelectorAll('.sql-pill-btn');

    if (templatePills) {
        templatePills.forEach(pill => {
            pill.addEventListener('click', () => {
                const sql = pill.getAttribute('data-sql');
                if (sqlTextarea && sql) {
                    sqlTextarea.value = sql;
                }
            });
        });
    }

    if (runBtn && sqlTextarea) {
        runBtn.addEventListener('click', () => executeSqlQuery(sqlTextarea.value));
    }
}

async function executeSqlQuery(sql) {
    if (!sql || !sql.trim()) {
        showToast('Please enter a SQL query to execute', 'warning');
        return;
    }

    const resultsContainer = document.getElementById('sql-results-container');
    const statusBox = document.getElementById('sql-status-box');

    if (statusBox) statusBox.innerHTML = '<span class="text-muted"><i class="fas fa-spinner fa-spin"></i> Executing SQL query against SQLite database...</span>';

    try {
        const res = await fetch('/api/sql/execute', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ sql })
        });
        const data = await res.json();

        if (data.success) {
            if (statusBox) {
                statusBox.innerHTML = `<span style="color: var(--accent-success);"><i class="fas fa-check-circle"></i> Executed successfully. Returned ${data.row_count} rows.</span>`;
            }
            renderSqlResultsTable(resultsContainer, data.columns, data.data);
        } else {
            if (statusBox) {
                statusBox.innerHTML = `<span style="color: var(--accent-danger);"><i class="fas fa-exclamation-triangle"></i> Error: ${data.error}</span>`;
            }
            if (resultsContainer) resultsContainer.innerHTML = '';
        }
    } catch (err) {
        if (statusBox) {
            statusBox.innerHTML = `<span style="color: var(--accent-danger);"><i class="fas fa-exclamation-triangle"></i> Failed to communicate with SQL engine: ${err.message}</span>`;
        }
    }
}

function renderSqlResultsTable(container, columns, rows) {
    if (!container) return;

    if (!rows || !rows.length) {
        container.innerHTML = '<div class="text-muted p-3">Query executed successfully, but returned 0 rows.</div>';
        return;
    }

    let html = `
        <div class="table-responsive">
            <table class="data-table">
                <thead>
                    <tr>${columns.map(c => `<th>${c}</th>`).join('')}</tr>
                </thead>
                <tbody>
                    ${rows.map(row => `
                        <tr>
                            ${columns.map(c => `<td>${row[c] !== null && row[c] !== undefined ? row[c] : ''}</td>`).join('')}
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        </div>
    `;
    container.innerHTML = html;
}

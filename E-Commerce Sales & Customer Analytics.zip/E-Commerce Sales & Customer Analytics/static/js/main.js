/**
 * Main UI Controller for E-Commerce Sales & Customer Analytics Dashboard
 * Handles theme toggling, interactive filter updates, exports, file uploads, notifications.
 */

document.addEventListener('DOMContentLoaded', () => {
    initTheme();
    initFilterListeners();
    initUploadModal();
});

/* --- Theme Management --- */
function initTheme() {
    const savedTheme = localStorage.getItem('bi_theme') || 'dark';
    if (savedTheme === 'light') {
        document.body.classList.add('light-mode');
        updateThemeIcon('light');
    } else {
        document.body.classList.remove('light-mode');
        updateThemeIcon('dark');
    }
}

function toggleTheme() {
    const isLight = document.body.classList.toggle('light-mode');
    const theme = isLight ? 'light' : 'dark';
    localStorage.setItem('bi_theme', theme);
    updateThemeIcon(theme);
    
    // Re-render charts to adjust background colors for active theme
    if (typeof loadPageAnalytics === 'function') {
        loadPageAnalytics();
    }
}

function updateThemeIcon(theme) {
    const icon = document.getElementById('theme-icon');
    if (icon) {
        icon.className = theme === 'light' ? 'fas fa-sun' : 'fas fa-moon';
    }
}

/* --- Filter & Analytics Loader --- */
function getActiveFilters() {
    return {
        start_date: document.getElementById('filter-start-date')?.value || '',
        end_date: document.getElementById('filter-end-date')?.value || '',
        category: document.getElementById('filter-category')?.value || 'All',
        region: document.getElementById('filter-region')?.value || 'All',
        customer_type: document.getElementById('filter-customer-type')?.value || 'All',
        product_id: document.getElementById('filter-product')?.value || 'All'
    };
}

function initFilterListeners() {
    const filterBtn = document.getElementById('apply-filters-btn');
    const resetBtn = document.getElementById('reset-filters-btn');

    if (filterBtn) {
        filterBtn.addEventListener('click', () => {
            if (typeof loadPageAnalytics === 'function') {
                loadPageAnalytics();
            }
        });
    }

    if (resetBtn) {
        resetBtn.addEventListener('click', () => {
            const inputs = ['filter-start-date', 'filter-end-date'];
            inputs.forEach(id => {
                const el = document.getElementById(id);
                if (el) el.value = '';
            });

            const selects = ['filter-category', 'filter-region', 'filter-customer-type', 'filter-product'];
            selects.forEach(id => {
                const el = document.getElementById(id);
                if (el) el.value = 'All';
            });

            if (typeof loadPageAnalytics === 'function') {
                loadPageAnalytics();
            }
        });
    }
}

/* --- Dataset Upload Handler --- */
function initUploadModal() {
    const uploadForm = document.getElementById('upload-dataset-form');
    if (uploadForm) {
        uploadForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const fileInput = document.getElementById('dataset-file-input');
            if (!fileInput.files.length) {
                showToast('Please select a CSV or Excel file', 'warning');
                return;
            }

            const formData = new FormData();
            formData.append('dataset_file', fileInput.files[0]);

            showToast('Uploading & running automated Pandas data cleaning...', 'info');

            try {
                const res = await fetch('/api/data/upload', {
                    method: 'POST',
                    body: formData
                });
                const data = await res.json();

                if (res.ok && data.status === 'success') {
                    showToast(data.message, 'success');
                    setTimeout(() => window.location.reload(), 1200);
                } else {
                    showToast(data.message || 'Error processing dataset', 'danger');
                }
            } catch (err) {
                showToast('Network error while uploading dataset: ' + err.message, 'danger');
            }
        });
    }
}

async function resetDemoData() {
    if (!confirm('Are you sure you want to reset the dataset to the default 1200+ transaction demo dataset?')) return;
    
    showToast('Resetting dataset to demo benchmark data...', 'info');
    try {
        const res = await fetch('/api/data/reset', { method: 'POST' });
        const data = await res.json();
        if (data.status === 'success') {
            showToast('Dataset reset successfully!', 'success');
            setTimeout(() => window.location.reload(), 1000);
        }
    } catch (err) {
        showToast('Failed to reset dataset: ' + err.message, 'danger');
    }
}

/* --- Notification Toast System --- */
function showToast(message, type = 'info') {
    let container = document.getElementById('toast-container');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toast-container';
        container.style.cssText = 'position: fixed; bottom: 20px; right: 20px; z-index: 9999; display: flex; flex-direction: column; gap: 10px;';
        document.body.appendChild(container);
    }

    const toast = document.createElement('div');
    const bgMap = {
        success: '#10b981',
        danger: '#f43f5e',
        warning: '#f59e0b',
        info: '#6366f1'
    };

    toast.style.cssText = `background: ${bgMap[type] || bgMap.info}; color: white; padding: 12px 20px; border-radius: 8px; font-weight: 500; font-size: 0.88rem; box-shadow: 0 10px 25px rgba(0,0,0,0.3); transition: all 0.3s; opacity: 0; transform: translateY(10px);`;
    toast.innerText = message;
    container.appendChild(toast);

    setTimeout(() => {
        toast.style.opacity = '1';
        toast.style.transform = 'translateY(0)';
    }, 10);

    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateY(10px)';
        setTimeout(() => toast.remove(), 300);
    }, 4000);
}

import pandas as pd
import numpy as np
from datetime import datetime

def apply_filters(df, filters=None):
    """Applies interactive filters to pandas DataFrame."""
    if not filters:
        return df

    filtered_df = df.copy()

    # Date Filter
    if filters.get("start_date"):
        filtered_df = filtered_df[filtered_df["order_date"] >= filters["start_date"]]
    if filters.get("end_date"):
        filtered_df = filtered_df[filtered_df["order_date"] <= filters["end_date"]]

    # Category Filter
    if filters.get("category") and filters["category"] != "All":
        filtered_df = filtered_df[filtered_df["category"] == filters["category"]]

    # Region Filter
    if filters.get("region") and filters["region"] != "All":
        filtered_df = filtered_df[filtered_df["region"] == filters["region"]]

    # Customer Type Filter
    if filters.get("customer_type") and filters["customer_type"] != "All":
        filtered_df = filtered_df[filtered_df["customer_type"] == filters["customer_type"]]

    # Product Filter
    if filters.get("product_id") and filters["product_id"] != "All":
        filtered_df = filtered_df[filtered_df["product_id"] == filters["product_id"]]

    return filtered_df

def compute_executive_kpis(df):
    """Calculates overall Executive KPIs and financial metrics."""
    if df.empty:
        return {
            "total_revenue": 0.0,
            "total_profit": 0.0,
            "total_orders": 0,
            "total_customers": 0,
            "aov": 0.0,
            "profit_margin": 0.0,
            "total_units_sold": 0,
            "avg_discount": 0.0
        }

    total_revenue = float(df["sales_amount"].sum())
    total_profit = float(df["profit"].sum())
    total_orders = int(df["order_id"].nunique())
    total_customers = int(df["customer_id"].nunique())
    total_units_sold = int(df["quantity"].sum())
    
    aov = total_revenue / total_orders if total_orders > 0 else 0.0
    profit_margin = (total_profit / total_revenue * 100.0) if total_revenue > 0 else 0.0
    avg_discount = float(df["discount_percent"].mean()) if "discount_percent" in df.columns else 0.0

    return {
        "total_revenue": round(total_revenue, 2),
        "total_profit": round(total_profit, 2),
        "total_orders": total_orders,
        "total_customers": total_customers,
        "aov": round(aov, 2),
        "profit_margin": round(profit_margin, 2),
        "total_units_sold": total_units_sold,
        "avg_discount": round(avg_discount, 2)
    }

def compute_monthly_trends(df):
    """Computes monthly revenue, profit, and order count time series."""
    if df.empty:
        return []

    temp_df = df.copy()
    temp_df["month"] = pd.to_datetime(temp_df["order_date"]).dt.strftime("%Y-%m")
    
    monthly = temp_df.groupby("month").agg(
        revenue=("sales_amount", "sum"),
        profit=("profit", "sum"),
        orders=("order_id", "nunique"),
        units=("quantity", "sum")
    ).reset_index().sort_values("month")

    monthly["revenue"] = monthly["revenue"].round(2)
    monthly["profit"] = monthly["profit"].round(2)
    monthly["margin"] = np.where(monthly["revenue"] > 0, (monthly["profit"] / monthly["revenue"] * 100).round(2), 0.0)

    return monthly.to_dict(orient="records")

def compute_category_analytics(df):
    """Computes sales, profit, and margins broken down by category & subcategory."""
    if df.empty:
        return {"by_category": [], "by_subcategory": []}

    cat_df = df.groupby("category").agg(
        revenue=("sales_amount", "sum"),
        profit=("profit", "sum"),
        orders=("order_id", "nunique"),
        units=("quantity", "sum")
    ).reset_index().sort_values("revenue", ascending=False)

    cat_df["revenue"] = cat_df["revenue"].round(2)
    cat_df["profit"] = cat_df["profit"].round(2)
    cat_df["margin_pct"] = np.where(cat_df["revenue"] > 0, (cat_df["profit"] / cat_df["revenue"] * 100).round(2), 0.0)

    subcat_df = df.groupby(["category", "subcategory"]).agg(
        revenue=("sales_amount", "sum"),
        profit=("profit", "sum"),
        units=("quantity", "sum")
    ).reset_index().sort_values("revenue", ascending=False)

    subcat_df["revenue"] = subcat_df["revenue"].round(2)
    subcat_df["profit"] = subcat_df["profit"].round(2)
    subcat_df["margin_pct"] = np.where(subcat_df["revenue"] > 0, (subcat_df["profit"] / subcat_df["revenue"] * 100).round(2), 0.0)

    return {
        "by_category": cat_df.to_dict(orient="records"),
        "by_subcategory": subcat_df.to_dict(orient="records")
    }

def compute_product_performance(df):
    """Identifies top bestsellers, most profitable, and low-margin products."""
    if df.empty:
        return {"top_revenue": [], "top_quantity": [], "low_margin": []}

    prod_df = df.groupby(["product_id", "product_name", "category"]).agg(
        revenue=("sales_amount", "sum"),
        profit=("profit", "sum"),
        units=("quantity", "sum"),
        orders=("order_id", "nunique")
    ).reset_index()

    prod_df["revenue"] = prod_df["revenue"].round(2)
    prod_df["profit"] = prod_df["profit"].round(2)
    prod_df["margin_pct"] = np.where(prod_df["revenue"] > 0, (prod_df["profit"] / prod_df["revenue"] * 100).round(2), 0.0)

    top_revenue = prod_df.sort_values("revenue", ascending=False).head(10).to_dict(orient="records")
    top_quantity = prod_df.sort_values("units", ascending=False).head(10).to_dict(orient="records")
    low_margin = prod_df.sort_values("margin_pct", ascending=True).head(5).to_dict(orient="records")

    return {
        "top_revenue": top_revenue,
        "top_quantity": top_quantity,
        "low_margin": low_margin
    }

def compute_rfm_segmentation(df):
    """
    Computes RFM (Recency, Frequency, Monetary) Customer Analytics & Segmentation.
    Categorizes customers into Champions, Loyal, Potential Loyalists, At Risk, and Hibernating.
    """
    if df.empty:
        return {
            "summary": [],
            "repeat_rate": 0.0,
            "segment_counts": {},
            "top_customers": []
        }

    # Use max date in dataset as snapshot date
    max_date = pd.to_datetime(df["order_date"]).max()

    rfm_df = df.groupby(["customer_id", "customer_name", "customer_type"]).agg(
        last_order_date=("order_date", "max"),
        frequency=("order_id", "nunique"),
        monetary=("sales_amount", "sum"),
        total_profit=("profit", "sum")
    ).reset_index()

    rfm_df["last_order_date"] = pd.to_datetime(rfm_df["last_order_date"])
    rfm_df["recency"] = (max_date - rfm_df["last_order_date"]).dt.days

    rfm_df["monetary"] = rfm_df["monetary"].round(2)
    rfm_df["total_profit"] = rfm_df["total_profit"].round(2)

    # Compute RFM Scores (1 to 4 scale based on quantiles or bin thresholds)
    rfm_df["r_score"] = pd.qcut(rfm_df["recency"], 4, labels=[4, 3, 2, 1], duplicates='drop')
    rfm_df["f_score"] = pd.qcut(rfm_df["frequency"].rank(method='first'), 4, labels=[1, 2, 3, 4], duplicates='drop')
    rfm_df["m_score"] = pd.qcut(rfm_df["monetary"], 4, labels=[1, 2, 3, 4], duplicates='drop')

    # Convert to numeric
    rfm_df["r_score"] = rfm_df["r_score"].astype(int)
    rfm_df["f_score"] = rfm_df["f_score"].astype(int)
    rfm_df["m_score"] = rfm_df["m_score"].astype(int)

    # Segment Mapping Function
    def assign_segment(row):
        r, f, m = row["r_score"], row["f_score"], row["m_score"]
        if r >= 3 and f >= 3 and m >= 3:
            return "Champions"
        elif f >= 3 and m >= 2:
            return "Loyal Customers"
        elif r >= 3 and f <= 2:
            return "Potential Loyalists"
        elif r <= 2 and f >= 2:
            return "At Risk"
        else:
            return "Hibernating"

    rfm_df["segment"] = rfm_df.apply(assign_segment, axis=1)

    # Segment Summary
    seg_summary = rfm_df.groupby("segment").agg(
        customer_count=("customer_id", "count"),
        avg_recency=("recency", "mean"),
        avg_frequency=("frequency", "mean"),
        total_revenue=("monetary", "sum"),
        total_profit=("total_profit", "sum")
    ).reset_index().sort_values("total_revenue", ascending=False)

    seg_summary["avg_recency"] = seg_summary["avg_recency"].round(1)
    seg_summary["avg_frequency"] = seg_summary["avg_frequency"].round(1)
    seg_summary["total_revenue"] = seg_summary["total_revenue"].round(2)
    seg_summary["total_profit"] = seg_summary["total_profit"].round(2)

    total_customers = len(rfm_df)
    repeat_customers = len(rfm_df[rfm_df["frequency"] > 1])
    repeat_rate = round((repeat_customers / total_customers * 100.0), 2) if total_customers > 0 else 0.0

    top_customers = rfm_df.sort_values("monetary", ascending=False).head(10).to_dict(orient="records")

    return {
        "segments": seg_summary.to_dict(orient="records"),
        "repeat_rate": repeat_rate,
        "total_customers": total_customers,
        "repeat_customers": repeat_customers,
        "top_customers": top_customers
    }

def compute_regional_performance(df):
    """Computes Sales, Profit, and Orders by Region, State, Payment Method, and Order Status."""
    if df.empty:
        return {"by_region": [], "by_state": [], "payment_methods": [], "order_statuses": []}

    reg_df = df.groupby("region").agg(
        revenue=("sales_amount", "sum"),
        profit=("profit", "sum"),
        orders=("order_id", "nunique"),
        customers=("customer_id", "nunique")
    ).reset_index().sort_values("revenue", ascending=False)

    reg_df["revenue"] = reg_df["revenue"].round(2)
    reg_df["profit"] = reg_df["profit"].round(2)
    reg_df["margin_pct"] = np.where(reg_df["revenue"] > 0, (reg_df["profit"] / reg_df["revenue"] * 100).round(2), 0.0)

    state_df = df.groupby(["state", "region"]).agg(
        revenue=("sales_amount", "sum"),
        profit=("profit", "sum"),
        orders=("order_id", "nunique")
    ).reset_index().sort_values("revenue", ascending=False).head(12)

    state_df["revenue"] = state_df["revenue"].round(2)
    state_df["profit"] = state_df["profit"].round(2)

    payment_df = df.groupby("payment_method").agg(
        revenue=("sales_amount", "sum"),
        orders=("order_id", "count")
    ).reset_index().sort_values("revenue", ascending=False)
    payment_df["revenue"] = payment_df["revenue"].round(2)

    status_df = df.groupby("order_status").agg(
        orders=("order_id", "count"),
        revenue=("sales_amount", "sum")
    ).reset_index().sort_values("orders", ascending=False)
    status_df["revenue"] = status_df["revenue"].round(2)

    return {
        "by_region": reg_df.to_dict(orient="records"),
        "by_state": state_df.to_dict(orient="records"),
        "payment_methods": payment_df.to_dict(orient="records"),
        "order_statuses": status_df.to_dict(orient="records")
    }

def get_filter_options(df):
    """Returns available unique dropdown filter values from dataset."""
    if df.empty:
        return {"categories": [], "regions": [], "customer_types": [], "products": []}

    categories = ["All"] + sorted(df["category"].dropna().unique().tolist())
    regions = ["All"] + sorted(df["region"].dropna().unique().tolist())
    customer_types = ["All"] + sorted(df["customer_type"].dropna().unique().tolist())
    
    prods = df[["product_id", "product_name"]].drop_duplicates().sort_values("product_name")
    products_list = [{"id": "All", "name": "All Products"}] + [
        {"id": row["product_id"], "name": f"{row['product_name']} ({row['product_id']})"} for _, row in prods.iterrows()
    ]

    min_date = df["order_date"].min()
    max_date = df["order_date"].max()

    return {
        "categories": categories,
        "regions": regions,
        "customer_types": customer_types,
        "products": products_list,
        "min_date": str(min_date),
        "max_date": str(max_date)
    }

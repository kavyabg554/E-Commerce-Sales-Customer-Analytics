import sqlite3
import pandas as pd
import os

DB_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data", "ecommerce.db")

def get_db_connection():
    """Establishes and returns a SQLite database connection with row factory."""
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db(df):
    """
    Saves or refreshes the clean pandas DataFrame into SQLite table 'sales_data'.
    Creates indexes for rapid analytics queries.
    """
    conn = get_db_connection()
    df.to_sql("sales_data", conn, if_exists="replace", index=False)
    
    # Create indexes for high-performance filtering and aggregations
    cursor = conn.cursor()
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_order_date ON sales_data(order_date);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_category ON sales_data(category);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_region ON sales_data(region);")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_customer_id ON sales_data(customer_id);")
    conn.commit()
    conn.close()

def execute_custom_query(sql_query):
    """
    Executes user custom SQL query safely (Read-Only SELECT statements).
    Returns columns, records list, and query execution timing/status.
    """
    cleaned_sql = sql_query.strip()
    
    # Security check: Only allow SELECT or WITH queries to prevent DB corruption
    first_word = cleaned_sql.split()[0].upper() if cleaned_sql else ""
    if first_word not in ["SELECT", "WITH", "EXPLAIN"]:
        return {
            "success": False,
            "error": "Security Restriction: Only SELECT or read-only analytical SQL queries are permitted.",
            "columns": [],
            "data": [],
            "row_count": 0
        }

    conn = get_db_connection()
    try:
        cursor = conn.cursor()
        cursor.execute(cleaned_sql)
        rows = cursor.fetchall()
        
        if cursor.description:
            columns = [desc[0] for desc in cursor.description]
            data = [dict(row) for row in rows]
        else:
            columns = []
            data = []

        conn.close()
        return {
            "success": True,
            "error": None,
            "columns": columns,
            "data": data,
            "row_count": len(data)
        }
    except Exception as e:
        conn.close()
        return {
            "success": False,
            "error": str(e),
            "columns": [],
            "data": [],
            "row_count": 0
        }

def get_sql_templates():
    """Returns curated professional SQL analytics templates for MCA Data Analytics demo."""
    return [
        {
            "title": "Monthly Revenue & Profit Aggregation",
            "sql": "SELECT \n  strftime('%Y-%m', order_date) AS month,\n  COUNT(DISTINCT order_id) AS total_orders,\n  ROUND(SUM(sales_amount), 2) AS revenue,\n  ROUND(SUM(profit), 2) AS net_profit,\n  ROUND(AVG(profit_margin), 2) AS avg_margin_pct\nFROM sales_data\nGROUP BY month\nORDER BY month ASC;"
        },
        {
            "title": "Top 5 High-Revenue Categories",
            "sql": "SELECT \n  category,\n  COUNT(DISTINCT order_id) AS total_orders,\n  SUM(quantity) AS units_sold,\n  ROUND(SUM(sales_amount), 2) AS total_revenue,\n  ROUND(SUM(profit), 2) AS total_profit,\n  ROUND((SUM(profit)/SUM(sales_amount))*100, 2) AS margin_pct\nFROM sales_data\nGROUP BY category\nORDER BY total_revenue DESC\nLIMIT 5;"
        },
        {
            "title": "Customer Repeat Frequency & Loyalty",
            "sql": "SELECT \n  customer_id,\n  customer_name,\n  customer_type,\n  COUNT(order_id) AS total_orders,\n  ROUND(SUM(sales_amount), 2) AS lifetime_value,\n  MAX(order_date) AS last_purchase_date\nFROM sales_data\nGROUP BY customer_id\nHAVING total_orders > 1\nORDER BY total_orders DESC, lifetime_value DESC\nLIMIT 10;"
        },
        {
            "title": "Regional Sales & Profitability Matrix",
            "sql": "SELECT \n  region,\n  COUNT(DISTINCT state) AS states_covered,\n  COUNT(order_id) AS order_volume,\n  ROUND(SUM(sales_amount), 2) AS total_revenue,\n  ROUND(SUM(profit), 2) AS net_profit\nFROM sales_data\nGROUP BY region\nORDER BY total_revenue DESC;"
        },
        {
            "title": "Discount Level vs Profitability Analysis",
            "sql": "SELECT \n  CASE \n    WHEN discount_percent = 0 THEN '0% No Discount'\n    WHEN discount_percent <= 10 THEN '1-10% Low Discount'\n    WHEN discount_percent <= 20 THEN '11-20% Med Discount'\n    ELSE '> 20% High Discount'\n  END AS discount_tier,\n  COUNT(order_id) AS order_count,\n  ROUND(SUM(sales_amount), 2) AS total_sales,\n  ROUND(SUM(profit), 2) AS total_profit,\n  ROUND(AVG(profit_margin), 2) AS avg_margin_pct\nFROM sales_data\nGROUP BY discount_tier\nORDER BY total_sales DESC;"
        }
    ]

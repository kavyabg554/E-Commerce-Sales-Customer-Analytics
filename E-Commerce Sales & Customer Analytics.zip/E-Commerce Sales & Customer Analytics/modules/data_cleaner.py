import pandas as pd
import numpy as np

def clean_ecommerce_data(df):
    """
    Automatic Data Cleaning & Preprocessing Pipeline using Pandas.
    Standardizes column names, cleans strings, handles missing data,
    converts types, removes duplicates, recalculates financial metrics,
    and produces a Data Quality Audit Report.
    """
    report = {
        "initial_rows": len(df),
        "initial_columns": len(df.columns),
        "missing_values_handled": 0,
        "whitespace_trimmed": 0,
        "duplicates_removed": 0,
        "type_conversions": 0,
        "health_score": 100
    }

    cleaned_df = df.copy()

    # 1. Standardize column names (lowercase & remove spaces)
    cleaned_df.columns = cleaned_df.columns.str.strip().str.lower().str.replace(' ', '_').str.replace('-', '_')

    # Expected column mappings for flexibility
    col_mapping = {
        "orderid": "order_id",
        "orderdate": "order_date",
        "customerid": "customer_id",
        "customername": "customer_name",
        "customertype": "customer_type",
        "productid": "product_id",
        "productname": "product_name",
        "sales": "sales_amount",
        "amount": "sales_amount",
        "cost": "unit_cost",
        "status": "order_status"
    }
    cleaned_df = cleaned_df.rename(columns=col_mapping)

    # 2. Trim string columns & count cleaned strings
    string_cols = cleaned_df.select_dtypes(include=['object', 'string']).columns
    for col in string_cols:
        before_trim = cleaned_df[col].astype(str)
        after_trim = before_trim.str.strip()
        trimmed_count = (before_trim != after_trim).sum()
        if trimmed_count > 0:
            report["whitespace_trimmed"] += int(trimmed_count)
        cleaned_df[col] = after_trim

    # 3. Handle Duplicate Rows based on order_id if present
    if 'order_id' in cleaned_df.columns:
        dups = cleaned_df.duplicated(subset=['order_id']).sum()
        if dups > 0:
            cleaned_df = cleaned_df.drop_duplicates(subset=['order_id'], keep='first')
            report["duplicates_removed"] += int(dups)
    else:
        dups = cleaned_df.duplicated().sum()
        if dups > 0:
            cleaned_df = cleaned_df.drop_duplicates(keep='first')
            report["duplicates_removed"] += int(dups)

    # 4. Standardize Date column
    if 'order_date' in cleaned_df.columns:
        cleaned_df['order_date'] = pd.to_datetime(cleaned_df['order_date'], errors='coerce')
        # Impute NaT dates with modern date
        missing_dates = cleaned_df['order_date'].isna().sum()
        if missing_dates > 0:
            cleaned_df['order_date'] = cleaned_df['order_date'].fillna(pd.Timestamp.now())
            report["missing_values_handled"] += int(missing_dates)
        cleaned_df['order_date'] = cleaned_df['order_date'].dt.strftime('%Y-%m-%d')
        report["type_conversions"] += 1

    # 5. Numeric fields handling & imputation
    num_fields = ['unit_price', 'quantity', 'discount_percent', 'sales_amount', 'unit_cost', 'profit', 'profit_margin']
    for num_col in num_fields:
        if num_col in cleaned_df.columns:
            cleaned_df[num_col] = pd.to_numeric(cleaned_df[num_col], errors='coerce')
            missing_count = cleaned_df[num_col].isna().sum()
            if missing_count > 0:
                report["missing_values_handled"] += int(missing_count)
                # Fill missing with 0 or median
                cleaned_df[num_col] = cleaned_df[num_col].fillna(0)
            report["type_conversions"] += 1

    # 6. Recalculate Derived Metrics if missing/incomplete
    if 'unit_price' in cleaned_df.columns and 'quantity' in cleaned_df.columns:
        if 'discount_percent' not in cleaned_df.columns:
            cleaned_df['discount_percent'] = 0.0
        
        # Calculate sales amount if zero or missing
        calculated_sales = (cleaned_df['unit_price'] * cleaned_df['quantity'] * (1 - cleaned_df['discount_percent'] / 100.0)).round(2)
        if 'sales_amount' not in cleaned_df.columns or cleaned_df['sales_amount'].eq(0).all():
            cleaned_df['sales_amount'] = calculated_sales

        if 'unit_cost' in cleaned_df.columns:
            total_cost = (cleaned_df['unit_cost'] * cleaned_df['quantity']).round(2)
            calculated_profit = (cleaned_df['sales_amount'] - total_cost).round(2)
            if 'profit' not in cleaned_df.columns or cleaned_df['profit'].eq(0).all():
                cleaned_df['profit'] = calculated_profit

            # Recalculate profit margin
            cleaned_df['profit_margin'] = np.where(
                cleaned_df['sales_amount'] > 0,
                ((cleaned_df['profit'] / cleaned_df['sales_amount']) * 100.0).round(2),
                0.0
            )

    # 7. Fill missing text columns
    text_cols = ['category', 'subcategory', 'region', 'state', 'city', 'payment_method', 'order_status', 'customer_type']
    for text_col in text_cols:
        if text_col in cleaned_df.columns:
            missing = cleaned_df[text_col].isna().sum()
            if missing > 0:
                report["missing_values_handled"] += int(missing)
                cleaned_df[text_col] = cleaned_df[text_col].fillna("Unspecified")

    # 8. Calculate Final Data Health Score
    report["final_rows"] = len(cleaned_df)
    total_issues = report["missing_values_handled"] + report["duplicates_removed"]
    deduction = min(35, (total_issues / max(1, report["initial_rows"])) * 100)
    report["health_score"] = round(max(65.0, 100.0 - deduction), 1)

    return cleaned_df, report

def generate_automated_insights(kpis, category_data, product_data, rfm_data, regional_data):
    """
    Generates rule-based corporate business insights, executive commentary,
    growth opportunities, and operational risk alerts based on actual data.
    """
    insights = []
    recommendations = []
    risk_alerts = []

    # 1. Executive Revenue & Profitability Insight
    revenue = kpis.get("total_revenue", 0)
    profit = kpis.get("total_profit", 0)
    margin = kpis.get("profit_margin", 0)
    aov = kpis.get("aov", 0)

    if margin >= 25.0:
        insights.append({
            "type": "success",
            "title": "Robust Profitability Standard",
            "body": f"The business operates with a strong net profit margin of {margin}%, generating ${profit:,.2f} net profit from ${revenue:,.2f} gross revenue."
        })
    elif margin >= 15.0:
        insights.append({
            "type": "info",
            "title": "Healthy Operating Margins",
            "body": f"Current overall profit margin stands at {margin}%. Total order volume of {kpis.get('total_orders', 0):,} yields an Average Order Value (AOV) of ${aov:,.2f}."
        })
    else:
        risk_alerts.append({
            "title": "Margin Pressure Warning",
            "body": f"Overall profit margin is currently compressed at {margin}%. High discount rates or elevated unit costs require pricing review."
        })

    # 2. Category Performance Drivers
    by_cat = category_data.get("by_category", [])
    if by_cat:
        top_cat = by_cat[0]
        cat_share = (top_cat["revenue"] / revenue * 100.0) if revenue > 0 else 0.0
        insights.append({
            "type": "primary",
            "title": f"Dominant Revenue Category: {top_cat['category']}",
            "body": f"The '{top_cat['category']}' sector drives {cat_share:.1f}% of gross revenue (${top_cat['revenue']:,.2f}) with a profit margin of {top_cat['margin_pct']}%."
        })

        low_margin_cats = [c for c in by_cat if c.get("margin_pct", 0) < 15.0]
        if low_margin_cats:
            recommendations.append({
                "action": f"Optimize Discount Policy in {low_margin_cats[0]['category']}",
                "detail": f"{low_margin_cats[0]['category']} exhibits lower profit margins ({low_margin_cats[0]['margin_pct']}%). Consider reducing high promotional discounts."
            })

    # 3. Customer Retention & RFM Insights
    repeat_rate = rfm_data.get("repeat_rate", 0.0)
    segments = rfm_data.get("segments", [])
    
    if repeat_rate >= 30.0:
        insights.append({
            "type": "success",
            "title": "Strong Customer Loyalty",
            "body": f"Customer repeat purchase rate is {repeat_rate}%. A strong recurring customer base lowers customer acquisition costs (CAC)."
        })
    else:
        recommendations.append({
            "action": "Implement Automated Retention Workflows",
            "detail": f"Customer repeat rate is at {repeat_rate}%. Launch targeted loyalty rewards and re-engagement campaigns for 'Potential Loyalists'."
        })

    at_risk_seg = next((s for s in segments if s.get("segment") == "At Risk"), None)
    if at_risk_seg:
        risk_alerts.append({
            "title": f"{at_risk_seg['customer_count']} Customers 'At Risk'",
            "body": f"The At-Risk customer group previously generated ${at_risk_seg['total_revenue']:,.2f} in revenue but hasn't purchased recently. Win-back promotions recommended."
        })

    # 4. Regional Expansion Insight
    by_region = regional_data.get("by_region", [])
    if by_region:
        top_region = by_region[0]
        insights.append({
            "type": "info",
            "title": f"Top Performing Region: {top_region['region']}",
            "body": f"The {top_region['region']} region leads sales generating ${top_region['revenue']:,.2f} across {top_region['orders']} orders."
        })

    # 5. Product Level Recommendations
    low_margin_prods = product_data.get("low_margin", [])
    if low_margin_prods:
        recommendations.append({
            "action": f"Supplier Re-negotiation for '{low_margin_prods[0]['product_name']}'",
            "detail": f"Product '{low_margin_prods[0]['product_name']}' has a lower margin of {low_margin_prods[0]['margin_pct']}%. Negotiate bulk wholesale pricing or increase retail price."
        })

    # Default fallback recommendations if empty
    if not recommendations:
        recommendations.append({
            "action": "Cross-Selling & Bundling Strategy",
            "detail": "Combine top electronics accessories with laptops in bundled discount packages to boost Average Order Value (AOV)."
        })

    return {
        "insights": insights,
        "recommendations": recommendations,
        "risk_alerts": risk_alerts
    }

import os
import io
import pandas as pd
from flask import Flask, render_template, request, jsonify, redirect, url_for, session, send_file, flash
from werkzeug.utils import secure_filename

from config import Config
from generate_data import generate_ecommerce_dataset
from modules.data_cleaner import clean_ecommerce_data
from modules.db_engine import init_db, execute_custom_query, get_sql_templates
from modules.analytics_engine import (
    apply_filters, compute_executive_kpis, compute_monthly_trends,
    compute_category_analytics, compute_product_performance,
    compute_rfm_segmentation, compute_regional_performance, get_filter_options
)
from modules.insight_generator import generate_automated_insights

app = Flask(__name__)
app.config.from_object(Config)

# Global memory cache for current DataFrame and data cleaning report
CURRENT_DF = None
DATA_AUDIT_REPORT = None

def get_current_data():
    """Loads dataset from CSV file or generates demo dataset if missing."""
    global CURRENT_DF, DATA_AUDIT_REPORT
    if CURRENT_DF is None:
        csv_path = app.config['DATASET_PATH']
        if not os.path.exists(csv_path):
            generate_ecommerce_dataset(csv_path, num_records=1200)
            
        raw_df = pd.read_csv(csv_path)
        CURRENT_DF, DATA_AUDIT_REPORT = clean_ecommerce_data(raw_df)
        init_db(CURRENT_DF)
        
    return CURRENT_DF, DATA_AUDIT_REPORT

@app.before_request
def ensure_data_loaded():
    """Ensure dataset and DB are initialized on startup."""
    if request.endpoint and not request.endpoint.startswith('static'):
        get_current_data()

# --- Page Routes ---

@app.route('/')
def index():
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    return redirect(url_for('dashboard'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        # Demo credentials check or quick login
        if (username == 'admin' and password == 'admin123') or request.form.get('demo_login') == 'true':
            session['logged_in'] = True
            session['user_name'] = 'Senior BI Analyst'
            session['user_role'] = 'MCA Analytics Lead'
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid credentials. Use demo login or admin / admin123', 'danger')

    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    flash('Logged out successfully.', 'info')
    return redirect(url_for('login'))

@app.route('/dashboard')
def dashboard():
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    df, _ = get_current_data()
    filter_opts = get_filter_options(df)
    return render_template('dashboard.html', page_title="Executive Dashboard", filters=filter_opts)

@app.route('/products')
def products():
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    df, _ = get_current_data()
    filter_opts = get_filter_options(df)
    return render_template('products.html', page_title="Products & Categories", filters=filter_opts)

@app.route('/customers')
def customers():
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    df, _ = get_current_data()
    filter_opts = get_filter_options(df)
    return render_template('customers.html', page_title="Customer & RFM Analytics", filters=filter_opts)

@app.route('/regional')
def regional():
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    df, _ = get_current_data()
    filter_opts = get_filter_options(df)
    return render_template('regional.html', page_title="Regional Performance", filters=filter_opts)

@app.route('/data-management')
def data_management():
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    df, audit_report = get_current_data()
    filter_opts = get_filter_options(df)
    sql_templates = get_sql_templates()
    
    # Send preview sample rows
    preview_data = df.head(15).to_dict(orient='records')
    columns = df.columns.tolist()

    return render_template('data_management.html', 
                           page_title="Data & SQL Console", 
                           filters=filter_opts,
                           audit_report=audit_report,
                           sql_templates=sql_templates,
                           preview_data=preview_data,
                           columns=columns)

@app.route('/insights')
def insights():
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    df, _ = get_current_data()
    filter_opts = get_filter_options(df)
    return render_template('insights.html', page_title="Automated Business Insights", filters=filter_opts)


# --- REST API Endpoints ---

@app.route('/api/analytics/all', methods=['GET', 'POST'])
def api_get_all_analytics():
    """Returns calculated analytics JSON based on active dashboard filters."""
    df, _ = get_current_data()
    
    if request.method == 'POST':
        filter_params = request.json or {}
    else:
        filter_params = {
            "start_date": request.args.get("start_date"),
            "end_date": request.args.get("end_date"),
            "category": request.args.get("category"),
            "region": request.args.get("region"),
            "customer_type": request.args.get("customer_type"),
            "product_id": request.args.get("product_id")
        }

    filtered_df = apply_filters(df, filter_params)

    kpis = compute_executive_kpis(filtered_df)
    trends = compute_monthly_trends(filtered_df)
    category_data = compute_category_analytics(filtered_df)
    product_data = compute_product_performance(filtered_df)
    rfm_data = compute_rfm_segmentation(filtered_df)
    regional_data = compute_regional_performance(filtered_df)
    ai_insights = generate_automated_insights(kpis, category_data, product_data, rfm_data, regional_data)

    return jsonify({
        "status": "success",
        "record_count": len(filtered_df),
        "total_record_count": len(df),
        "kpis": kpis,
        "trends": trends,
        "categories": category_data,
        "products": product_data,
        "rfm": rfm_data,
        "regional": regional_data,
        "insights": ai_insights
    })

@app.route('/api/data/upload', methods=['POST'])
def api_upload_dataset():
    """Handles CSV/Excel file uploads, runs data cleaner, and updates SQLite DB."""
    global CURRENT_DF, DATA_AUDIT_REPORT
    
    if 'dataset_file' not in request.files:
        return jsonify({"status": "error", "message": "No file uploaded"}), 400

    file = request.files['dataset_file']
    if file.filename == '':
        return jsonify({"status": "error", "message": "No selected file"}), 400

    filename = secure_filename(file.filename)
    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
    file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    file.save(file_path)

    try:
        if filename.endswith('.csv'):
            uploaded_df = pd.read_csv(file_path)
        elif filename.endswith(('.xls', '.xlsx')):
            uploaded_df = pd.read_excel(file_path)
        else:
            return jsonify({"status": "error", "message": "Unsupported file format. Please upload CSV or Excel (.xlsx)"}), 400

        # Clean and validate
        cleaned_df, report = clean_ecommerce_data(uploaded_df)
        
        # Check required columns
        if 'sales_amount' not in cleaned_df.columns:
            return jsonify({"status": "error", "message": "Dataset must contain sales price or quantity fields."}), 400

        # Overwrite current dataset
        CURRENT_DF = cleaned_df
        DATA_AUDIT_REPORT = report
        init_db(CURRENT_DF)

        # Save as main CSV
        CURRENT_DF.to_csv(app.config['DATASET_PATH'], index=False)

        return jsonify({
            "status": "success",
            "message": f"Successfully ingested and cleaned {report['final_rows']} records.",
            "report": report
        })

    except Exception as e:
        return jsonify({"status": "error", "message": f"Failed to process dataset: {str(e)}"}), 500

@app.route('/api/sql/execute', methods=['POST'])
def api_execute_sql():
    """Executes user raw SQL query safely against SQLite sales_data table."""
    data = request.json or {}
    sql = data.get('sql', '')
    if not sql:
        return jsonify({"success": False, "error": "No SQL query provided"}), 400

    result = execute_custom_query(sql)
    return jsonify(result)

@app.route('/api/data/reset', methods=['POST'])
def api_reset_data():
    """Resets dataset back to default synthetic 1200+ dataset."""
    global CURRENT_DF, DATA_AUDIT_REPORT
    generate_ecommerce_dataset(app.config['DATASET_PATH'], num_records=1200)
    raw_df = pd.read_csv(app.config['DATASET_PATH'])
    CURRENT_DF, DATA_AUDIT_REPORT = clean_ecommerce_data(raw_df)
    init_db(CURRENT_DF)
    return jsonify({"status": "success", "message": "Dataset reset to default 1200+ record sample."})

@app.route('/api/data/export/csv', methods=['GET'])
def api_export_csv():
    """Exports current cleaned dataset as a CSV file attachment."""
    df, _ = get_current_data()
    output = io.BytesIO()
    df.to_csv(output, index=False)
    output.seek(0)
    return send_file(
        output,
        mimetype="text/csv",
        as_attachment=True,
        download_name="ecommerce_analytics_cleaned.csv"
    )

if __name__ == '__main__':
    # Initialize dataset on main start
    get_current_data()
    app.run(debug=True, port=5000)
